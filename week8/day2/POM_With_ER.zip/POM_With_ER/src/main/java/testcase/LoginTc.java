package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.WelcomePage;

public class LoginTc extends ProjectSpecificMethod{
	
	
	@BeforeTest
	public void setValues() {
	
		testName="LoginTc";
		testDesc="Login with Positive credentials";
		author ="Saranya";
		category ="Funtional";
	}
	
	
	@Test
	public void runLogin() throws IOException {
		
		LoginPage lp=new LoginPage();
		lp.enterUsername().enterPassword().clickLogin().clickCRMSFA();
		
			
	
		
		
		
		
	}
	

}
