package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class CreateLeadTc extends ProjectSpecificMethod{

	@BeforeTest
	public void setValues() {
		filename="Lead";
		testName="CreateLead";
		testDesc="Create Lead with mandantory fields";
		author ="Saranya";
		category ="Funtional";
	}
	
	
	@Test(dataProvider ="fetchData")
	public void runCreate(String cname,String fname,String lname) throws IOException {
		new LoginPage().enterUsername().enterPassword().clickLogin().clickCRMSFA()
		.clickLeads().clickCreateLead().enterCompanyName(cname).enterfirstName(fname)
		.enterlastName(lname).clickCreate() .verifyfirstName();
		
	}
	
}
