package base;

import java.io.IOException;

public class LearnExceptionHandling {

	public static void main(String[] args) throws IOException {
		
		String s=null;
		int[] a= {1,2,2};
		try {
		System.out.println(4/2);
		System.out.println(a[4]);
	//	System.out.println(s.length());		
		}finally {
			System.out.println("Kill the chromedriver");
			Runtime.getRuntime().exec("taskkill /f /im chromedriver.exe");
		}
		System.out.println("End of Program");
		
	}

}
