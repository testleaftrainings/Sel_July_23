package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {
		// Step:1 Create a folder to store the report
		// Step:2 To set the path of report to capture the results -Physical file
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./report/result.html");

		reporter.setAppendExisting(true);
		// step:3 To attach the results into physical file
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(reporter);
		
		//Step:4 add the testcase name, desc of the testcase,category ,Who 
		ExtentTest createTest = extent.createTest("LoginTc","Login with Positive Credentials");
		createTest.assignAuthor("DiptiRanjan");
		createTest.assignCategory("Functional Testing");
		
		createTest.pass("Login is successful");
		createTest.fail("Login is not Successful",MediaEntityBuilder.createScreenCaptureFromPath(".././snap/pic.jpg").build());
		
		
		//mandatory step
		extent.flush(); //to write the report steps into the physical file 
		
		

	}

}
