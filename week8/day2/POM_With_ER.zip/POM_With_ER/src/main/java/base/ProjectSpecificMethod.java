package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import confiManager.ConfigurationManager;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {

	private static final ThreadLocal<RemoteWebDriver> tlDriver = new ThreadLocal<RemoteWebDriver>();

	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}

	public void setDriver() {
		tlDriver.set(new ChromeDriver());
	}

	private static final ThreadLocal<Properties> tlprop = new ThreadLocal<Properties>();

	public Properties getProp() {
		return tlprop.get();
	}

	public void setProp() {
		tlprop.set(new Properties());
	}

	public static ExtentReports extent;
	// public static Properties prop;
	public String filename;
	public String testName, testDesc, category, author;
	public static ExtentTest test,node;

	@Parameters({ "language" })
	@BeforeMethod
	public void preCondition(String language) throws IOException, InterruptedException {
		node=test.createNode(testName);
		FileInputStream fis = new FileInputStream("./src/main/resources/" + language + ".properties");
		setProp();
		getProp().load(fis);
		setDriver();
		getDriver().get(ConfigurationManager.configuration().getUrl());
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(ConfigurationManager.configuration().getMintimeOut());

	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}

	@DataProvider(name = "fetchData")
	public String[][] sendData() throws IOException {
		String[][] readExcel = ReadExcel.readExcel(filename);
		return readExcel;

	}

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./report/result.html");
		reporter.setAppendExisting(true);
		// step:3 To attach the results into physical file
		extent = new ExtentReports();
		extent.attachReporter(reporter);

	}

	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDesc);
		test.assignAuthor(author);
		test.assignCategory(category);
	}

	public void reportStep(String message, String status) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			node.pass(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././shot/snap" + takeSnap() + ".jpg").build());
		} else if (status.equalsIgnoreCase("fail")) {
			node.fail(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././shot/snap" + takeSnap() + ".jpg").build());
		}
	}

	@AfterSuite
	public void endReport() {
		extent.flush();
	}

	public int takeSnap() throws IOException {
		int random = (int) (Math.random() * 999);
		File screenshotAs = getDriver().getScreenshotAs(OutputType.FILE);
		File destn = new File("./shot/snap" + random + ".jpg");
		FileUtils.copyFile(screenshotAs, destn);
		return random;

	}

}
