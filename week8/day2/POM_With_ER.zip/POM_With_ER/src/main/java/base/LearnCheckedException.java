package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class LearnCheckedException {

	public static void add(int a, int b) throws FileNotFoundException {
		if (a > b) {
			System.out.println(a / b);
		} else {

			throw new RuntimeException("Check your inputs");
		}
		
		FileInputStream f=new FileInputStream(".\\src\\main\\java\\inputfile.txt ");
	}

	public static void main(String[] args) throws FileNotFoundException  {

		add(6,3);
		
		
	}

}
