package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class HomePage extends ProjectSpecificMethod {
	
	
	
	public LeadsPage clickLeads() {
		getDriver().findElement(By.linkText(getProp().getProperty("HomePage.LinkText.Leads"))).click();
		return new LeadsPage();
	}
	
	
	public void clickContacts() {
		
	}


	
}
