package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {
	
	
	public LoginPage enterUsername() throws IOException {
		try {
		getDriver().findElement(By.id("username")).sendKeys(getProp().getProperty("username"));
	    reportStep("Entered the username successfully","pass");
		}catch(Exception e){
		 reportStep("Entering the username not successful","fail");
		}
		return this;
	}

	public LoginPage enterPassword() throws IOException {
		try {
		getDriver().findElement(By.id("password")).sendKeys("crmsfa");
		 reportStep("Entered the password successfully","pass");
		}
		catch(Exception e) {
			 reportStep("Entering  the password is not successful","fail");
		}
		return this;
	}

	public WelcomePage clickLogin() throws IOException {
		try {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		 reportStep("Login button is clicked successfully","pass");
		}catch(Exception e) {
			 reportStep("Login button is not clicked " +e,"pass");
		}
        return new WelcomePage();
	}

}
