package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod{

	

	public CreateLeadPage clickCreateLead() {
		getDriver().findElement(By.linkText(getProp().getProperty("LeadsPage.LinkText.CreateLead"))).click();
		return new CreateLeadPage();
		}

		/*
		 * public CreateLeadPage clickCreateLeadfr() {
		 * getDriver().findElement(By.linkText("Cr�er un prospect")).click(); return new
		 * CreateLeadPage(); }
		 */

	
}
